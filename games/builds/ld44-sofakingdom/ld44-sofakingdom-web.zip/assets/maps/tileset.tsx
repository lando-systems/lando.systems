<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="tileset" tilewidth="32" tileheight="32" spacing="4" margin="2" tilecount="196" columns="14">
 <image source="tileset.png" width="512" height="512"/>
</tileset>
