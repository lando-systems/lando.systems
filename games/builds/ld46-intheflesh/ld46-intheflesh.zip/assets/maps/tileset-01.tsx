<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="tileset-01" tilewidth="32" tileheight="32" spacing="4" margin="4" tilecount="784" columns="28">
 <image source="tileset-01.png" width="1024" height="1024"/>
</tileset>
