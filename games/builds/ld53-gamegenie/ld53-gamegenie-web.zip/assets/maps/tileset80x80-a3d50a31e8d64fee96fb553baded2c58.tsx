<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="tileset80x80" tilewidth="80" tileheight="80" tilecount="64" columns="8">
 <image source="tileset80x80.png" width="640" height="640"/>
</tileset>
